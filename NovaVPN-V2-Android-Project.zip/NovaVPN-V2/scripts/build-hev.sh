#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HEV="$ROOT/native/hev-socks5-tunnel"
: "${NDK_HOME:?Set NDK_HOME to the Android NDK directory}"
if [[ ! -f "$HEV/Android.mk" ]]; then
  mkdir -p "$(dirname "$HEV")"
  git clone --depth 1 https://github.com/heiher/hev-socks5-tunnel.git "$HEV"
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/jni"
ln -s "$HEV" "$TMP/jni/hev-socks5-tunnel"
echo 'include $(call all-subdir-makefiles)' > "$TMP/jni/Android.mk"
"$NDK_HOME/ndk-build" NDK_PROJECT_PATH="$TMP" APP_BUILD_SCRIPT="$TMP/jni/Android.mk" \
  APP_ABI="arm64-v8a armeabi-v7a x86 x86_64" APP_PLATFORM=android-24 \
  NDK_LIBS_OUT="$ROOT/app/libs" NDK_OUT="$TMP/obj" \
  APP_CFLAGS="-O3 -DPKGNAME=com/v2ray/ang/service" \
  APP_LDFLAGS="-Wl,--build-id=none -Wl,--hash-style=gnu -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384"
