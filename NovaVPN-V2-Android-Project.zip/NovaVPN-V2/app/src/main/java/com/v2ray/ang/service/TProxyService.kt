package com.v2ray.ang.service

/** JNI bridge for the HEV SOCKS5 TUN library built by scripts/build-hev.sh. */
object TProxyService {
    init { System.loadLibrary("hev-socks5-tunnel") }
    @JvmStatic private external fun TProxyStartService(configPath: String, fd: Int): Boolean
    @JvmStatic private external fun TProxyStopService(): Boolean
    @JvmStatic private external fun TProxyIsRunning(): Boolean
    @JvmStatic private external fun TProxyGetStats(): LongArray?
    fun start(path: String, fd: Int): Boolean = TProxyStartService(path, fd)
    fun stop(): Boolean = TProxyStopService()
}
