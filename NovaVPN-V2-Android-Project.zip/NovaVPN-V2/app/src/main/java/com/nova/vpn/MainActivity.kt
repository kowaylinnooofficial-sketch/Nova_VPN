package com.nova.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.nova.vpn.data.ProfileStore
import com.nova.vpn.data.VmessParser
import com.nova.vpn.vpn.WireGuardControllerService
import com.nova.vpn.vpn.XrayVpnService

private val Teal = Color(0xFF006B60)
private val DarkTeal = Color(0xFF073B36)

class MainActivity : ComponentActivity() {
    private lateinit var store: ProfileStore
    private var pendingWgConfig: String? = null
    private val profilesState = androidx.compose.runtime.mutableStateOf<List<ProfileStore.Profile>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        profilesState.value = store.getProfiles()
        setContent {
            NovaTheme {
                NovaHome(
                    onImportVmess = { text -> importVmess(text) },
                    onPickVmess = { pickVmess.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    onPickWg = { pickWireGuard.launch(arrayOf("*/*")) },
                    onConnectVmess = { profile -> startVmess(profile) },
                    onConnectWg = { config -> startWireGuard(config) },
                    onStop = { stopBoth() },
                    savedProfiles = profilesState.value,
                    onDeleteProfile = { store.delete(it); profilesState.value = store.getProfiles() }
                )
            }
        }
    }

    private val pickVmess = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        }.onSuccess { importVmess(it) }.onFailure { toast("Could not read configuration") }
    }

    private val pickWireGuard = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        }.onSuccess { config ->
            pendingWgConfig = config
            val permission = VpnService.prepare(this)
            if (permission == null) startWireGuard(config) else wgPermission.launch(permission)
        }.onFailure { toast("Could not read WireGuard config") }
    }

    private val wgPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) pendingWgConfig?.let { if (it.isNotBlank()) startWireGuard(it) }
        else toast("VPN permission was not granted")
    }

    private fun importVmess(raw: String) {
        runCatching { VmessParser.parse(raw) }
            .onSuccess { profile -> store.save(profile.name, profile.xrayJson); profilesState.value = store.getProfiles(); toast("VMess profile imported") }
            .onFailure { toast("Import failed: ${it.message ?: "invalid config"}") }
    }

    private fun startVmess(profile: ProfileStore.Profile) {
        stopService(Intent(this, WireGuardControllerService::class.java))
        val permission = VpnService.prepare(this)
        val intent = Intent(this, XrayVpnService::class.java).apply {
            action = XrayVpnService.ACTION_START
            putExtra(XrayVpnService.EXTRA_NAME, profile.name)
            putExtra(XrayVpnService.EXTRA_XRAY_JSON, profile.xrayJson)
        }
        if (permission == null) startForegroundService(intent)
        else { XrayVpnService.pendingStart = intent; xrayPermission.launch(permission) }
    }

    private val xrayPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) XrayVpnService.pendingStart?.let { startForegroundService(it) }
        else toast("VPN permission was not granted")
    }

    private fun startWireGuard(configText: String) {
        stopService(Intent(this, XrayVpnService::class.java))
        val f = java.io.File(filesDir, "nova-wireguard.conf")
        f.writeText(configText)
        startService(Intent(this, WireGuardControllerService::class.java).apply {
            action = WireGuardControllerService.ACTION_START
            putExtra(WireGuardControllerService.EXTRA_PATH, f.absolutePath)
        })
        toast("Starting WireGuard…")
    }

    private fun stopBoth() {
        stopService(Intent(this, WireGuardControllerService::class.java))
        stopService(Intent(this, XrayVpnService::class.java))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

@Composable
private fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Teal, onPrimary = Color.White, secondary = Color(0xFF4A635E),
        background = Color(0xFFF4F7F6), surface = Color.White, surfaceVariant = Color(0xFFE3EEEB)
    ), content = content)
}

@Composable
private fun NovaHome(
    onImportVmess: (String) -> Unit, onPickVmess: () -> Unit, onPickWg: () -> Unit,
    onConnectVmess: (ProfileStore.Profile) -> Unit, onConnectWg: (String) -> Unit,
    onStop: () -> Unit, savedProfiles: List<ProfileStore.Profile>, onDeleteProfile: (String) -> Unit
) {
    var tab by remember { mutableStateOf("VMess") }
    var vmessText by remember { mutableStateOf("") }
    var wgText by remember { mutableStateOf("") }
    var selected by remember(savedProfiles) { mutableStateOf(savedProfiles.firstOrNull()) }
    var showProfiles by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBarNova(onSettings = { showProfiles = true })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = false, onClick = { showProfiles = true }, icon = { Icon(Icons.Default.Dns, null) }, label = { Text("Servers") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(padding).padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item { Spacer(Modifier.height(18.dp)); Text("PRIVATE CONNECTION", color = Teal, letterSpacing = 2.sp, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
            item {
                Spacer(Modifier.height(18.dp))
                Surface(shape = CircleShape, color = Color(0xFFDCEFEA), modifier = Modifier.size(142.dp), onClick = onStop) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.PowerSettingsNew, null, tint = Teal, modifier = Modifier.size(64.dp)) }
                }
                Spacer(Modifier.height(10.dp))
                Text("Ready to connect", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text("Choose a profile and start your secure tunnel", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            item {
                Spacer(Modifier.height(24.dp))
                Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("PROTOCOL", style = MaterialTheme.typography.labelMedium, color = Teal, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            listOf("VMess", "WireGuard").forEachIndexed { i, label ->
                                SegmentedButton(selected = tab == label, onClick = { tab = label }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(label) }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        if (tab == "VMess") {
                            OutlinedTextField(vmessText, { vmessText = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("vmess:// link or Xray JSON") }, placeholder = { Text("Paste configuration…") })
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = onPickVmess, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Import JSON") }
                                Button(onClick = { onImportVmess(vmessText); vmessText = "" }, modifier = Modifier.weight(1f), enabled = vmessText.isNotBlank()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Import link") }
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(selected?.name ?: "No VMess profile", fontWeight = FontWeight.SemiBold)
                                    Text("${savedProfiles.size} saved profile(s)", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton(onClick = { showProfiles = true }) { Text("Manage") }
                            }
                            Button(onClick = { selected?.let(onConnectVmess) }, modifier = Modifier.fillMaxWidth(), enabled = selected != null) { Icon(Icons.Default.Shield, null); Spacer(Modifier.width(8.dp)); Text("CONNECT VMESS") }
                        } else {
                            Text("Import your WireGuard provider configuration (.conf).", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = onPickWg, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("IMPORT .CONF FILE") }
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(14.dp))
                Card(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.VerifiedUser, tint = Teal, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Connection controls", fontWeight = FontWeight.SemiBold) }
                        Spacer(Modifier.height(8.dp))
                        Text("Stop the active tunnel", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.StopCircle, null); Spacer(Modifier.width(8.dp)); Text("DISCONNECT ALL") }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("NOVA VPN • Your keys stay on this device", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showProfiles) AlertDialog(
        onDismissRequest = { showProfiles = false },
        title = { Text("Saved VMess profiles") },
        text = {
            Column {
                if (savedProfiles.isEmpty()) Text("No profiles imported yet.")
                savedProfiles.forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected?.id == p.id, onClick = { selected = p })
                        Text(p.name, modifier = Modifier.weight(1f))
                        IconButton(onClick = { onDeleteProfile(p.id); if (selected?.id == p.id) selected = null }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { showProfiles = false }) { Text("Done") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarNova(onSettings: () -> Unit) {
    CenterAlignedTopAppBar(
        title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Shield, null, tint = Teal); Spacer(Modifier.width(8.dp)); Text("NOVA VPN", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp) } },
        actions = { IconButton(onClick = onSettings) { Icon(Icons.Default.Dns, contentDescription = "Servers") } }
    )
}
