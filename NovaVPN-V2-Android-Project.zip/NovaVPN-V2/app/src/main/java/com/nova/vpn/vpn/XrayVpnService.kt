package com.nova.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import libXray.DialerController
import libXray.LibXray
import java.io.File

class XrayVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.nova.vpn.action.XRAY_START"
        const val ACTION_STOP = "com.nova.vpn.action.XRAY_STOP"
        const val EXTRA_NAME = "profile_name"
        const val EXTRA_XRAY_JSON = "xray_json"
        @Volatile var pendingStart: Intent? = null
        private const val CHANNEL = "nova_vpn"
    }

    private var tun: ParcelFileDescriptor? = null
    private var tunnelStarted = false
    private val controller = object : DialerController {
        override fun protectFd(fd: Int): Boolean = protect(fd)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(42, notification("Starting Xray tunnel…"))
        if (intent?.action == ACTION_STOP) { stopTunnel(); stopSelf(); return START_NOT_STICKY }
        if (intent?.action != ACTION_START) { stopSelf(); return START_NOT_STICKY }
        Thread {
            try {
                val raw = intent.getStringExtra(EXTRA_XRAY_JSON) ?: error("Missing Xray config")
                val profileName = intent.getStringExtra(EXTRA_NAME) ?: "VMess"
                LibXray.registerDialerController(controller)
                LibXray.setDNS(controller, "1.1.1.1:53")
                val xrayConfig = buildRuntimeConfig(raw)
                val run = invoke("runXray", JsonObject().apply { addProperty("xrayJson", xrayConfig) })
                check(run.get("success")?.asBoolean == true) { run.get("error")?.asString ?: "Xray failed to start" }
                val builder = Builder().setSession("NOVA VPN • $profileName").setMtu(1500)
                    .addAddress("10.111.0.1", 30).addRoute("0.0.0.0", 0)
                    .addAddress("fd00:1111:2222::1", 126).addRoute("::", 0).addDnsServer("1.1.1.1")
                if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
                val established = builder.establish() ?: error("Android did not create VPN interface")
                tun = established
                val cfg = """
                    tunnel:
                      mtu: 1500
                      ipv4: 10.111.0.1
                      ipv6: 'fd00:1111:2222::1'
                    socks5:
                      port: 10808
                      address: 127.0.0.1
                      udp: 'udp'
                    misc:
                      log-level: warn
                """.trimIndent()
                val configFile = File(filesDir, "hev-v2.yml").apply { writeText(cfg) }
                check(TProxyService.start(configFile.absolutePath, established.fd)) { "HEV tun2socks failed to start" }
                tunnelStarted = true
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(42, notification("Connected • $profileName"))
            } catch (e: Exception) {
                stopTunnel()
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(42, notification("Connection failed: ${e.message ?: "unknown error"}"))
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun buildRuntimeConfig(profileJson: String): String {
        val parsed = JsonParser.parseString(profileJson).asJsonObject
        val outbounds = parsed.getAsJsonArray("outbounds") ?: error("No outbounds")
        require(outbounds.size() > 0) { "No VMess outbound" }
        val config = JsonObject().apply {
            add("log", JsonObject().apply { addProperty("loglevel", "warning") })
            add("inbounds", com.google.gson.JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("tag", "socks-in"); addProperty("listen", "127.0.0.1"); addProperty("port", 10808)
                    addProperty("protocol", "socks")
                    add("settings", JsonObject().apply { addProperty("auth", "noauth"); addProperty("udp", true); addProperty("userLevel", 0) })
                })
            })
            add("outbounds", outbounds)
        }
        return config.toString()
    }

    private fun invoke(method: String, payload: JsonObject = JsonObject()) = JsonParser.parseString(
        LibXray.invoke(JsonObject().apply { addProperty("apiVersion", 3); addProperty("method", method); add("payload", payload) }.toString())
    ).asJsonObject

    private fun stopTunnel() {
        runCatching { if (tunnelStarted) TProxyService.stop() }
        tunnelStarted = false
        runCatching { invoke("stopXray") }
        runCatching { LibXray.resetDNS() }
        runCatching { tun?.close() }
        tun = null
    }

    override fun onRevoke() { stopTunnel(); stopSelf(); super.onRevoke() }
    override fun onDestroy() { stopTunnel(); super.onDestroy() }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "NOVA VPN", NotificationManager.IMPORTANCE_LOW))
        }
    }
    @Suppress("DEPRECATION")
    private fun notification(text: String): Notification =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("NOVA VPN").setContentText(text).setOngoing(true).build()
        else Notification.Builder(this).setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("NOVA VPN").setContentText(text).setOngoing(true).build()
}
