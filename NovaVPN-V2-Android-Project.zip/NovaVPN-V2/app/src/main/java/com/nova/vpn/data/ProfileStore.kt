package com.nova.vpn.data

import android.content.Context
import java.util.UUID

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("nova_profiles", Context.MODE_PRIVATE)
    data class Profile(val id: String, val name: String, val xrayJson: String)

    @Synchronized fun getProfiles(): List<Profile> = prefs.all.entries
        .filter { it.value is String }
        .mapNotNull { (id, value) -> runCatching {
            val raw = value as String
            val split = raw.indexOf('\n')
            require(split > 0)
            Profile(id, raw.substring(0, split), raw.substring(split + 1))
        }.getOrNull() }

    @Synchronized fun save(name: String, xrayJson: String) {
        val id = UUID.randomUUID().toString()
        prefs.edit().putString(id, name.replace('\n', ' ').take(80) + "\n" + xrayJson).apply()
    }

    @Synchronized fun delete(id: String) { prefs.edit().remove(id).apply() }
}
