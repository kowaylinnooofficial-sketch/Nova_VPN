package com.nova.vpn.vpn

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.File

class WireGuardControllerService : Service() {
    companion object {
        const val ACTION_START = "com.nova.vpn.action.WG_START"
        const val ACTION_STOP = "com.nova.vpn.action.WG_STOP"
        const val EXTRA_PATH = "config_path"
    }
    private lateinit var backend: GoBackend
    private val tunnel = object : Tunnel {
        override fun getName() = "NOVA-WireGuard"
        override fun onStateChange(newState: Tunnel.State) {}
    }
    override fun onCreate() { super.onCreate(); backend = GoBackend(this) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Thread {
            try {
                if (intent?.action == ACTION_STOP) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    stopSelf()
                } else if (intent?.action == ACTION_START) {
                    val path = intent.getStringExtra(EXTRA_PATH) ?: error("No config path")
                    val config = File(path).inputStream().use { Config.parse(it) }
                    backend.setState(tunnel, Tunnel.State.UP, config)
                }
            } catch (_: Exception) { stopSelf() }
        }.start()
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
