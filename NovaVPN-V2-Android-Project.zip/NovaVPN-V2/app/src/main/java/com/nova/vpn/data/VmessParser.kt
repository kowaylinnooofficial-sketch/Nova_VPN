package com.nova.vpn.data

import java.util.Base64
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.Gson

object VmessParser {
    data class Parsed(val name: String, val xrayJson: String)
    private val gson = Gson()

    fun parse(input: String): Parsed {
        val raw = input.trim()
        require(raw.isNotEmpty()) { "Empty input" }
        if (raw.startsWith("vmess://", true)) return parseLegacy(raw)
        val root = JsonParser.parseString(raw)
        val outbounds = when {
            root.isJsonObject && root.asJsonObject.has("outbounds") -> root.asJsonObject.getAsJsonArray("outbounds")
            root.isJsonObject && root.asJsonObject.has("protocol") -> com.google.gson.JsonArray().apply { add(root) }
            else -> throw IllegalArgumentException("Expected vmess:// link or Xray JSON with outbounds")
        }
        val vmess = outbounds.firstOrNull { it.isJsonObject && it.asJsonObject.get("protocol")?.asString == "vmess" }
            ?: throw IllegalArgumentException("No VMess outbound found in JSON")
        val name = vmess.asJsonObject.get("tag")?.asString ?: "VMess server"
        return Parsed(name, gson.toJson(JsonObject().apply { add("outbounds", outbounds) }))
    }

    private fun parseLegacy(link: String): Parsed {
        val encoded = link.substringAfter("://").substringBefore('#').trim()
        val bytes = try { Base64.getUrlDecoder().decode(pad(encoded)) }
            catch (_: Exception) { Base64.getDecoder().decode(pad(encoded)) }
        val v = JsonParser.parseString(String(bytes, Charsets.UTF_8)).asJsonObject
        fun str(key: String, default: String = ""): String = v.get(key)?.takeUnless { it.isJsonNull }?.asString ?: default
        val host = str("add").ifBlank { str("address") }
        val port = str("port").toIntOrNull() ?: throw IllegalArgumentException("Invalid port")
        val uuid = str("id").ifBlank { str("uuid") }
        require(host.isNotBlank() && port in 1..65535 && uuid.isNotBlank()) { "Missing server, port or UUID" }
        val network = str("net", "tcp").lowercase()
        require(network in setOf("tcp", "ws", "grpc", "http", "h2")) { "Unsupported VMess transport: $network" }
        val tls = str("tls").equals("tls", true) || str("tls").equals("true", true)
        val stream = JsonObject().apply {
            addProperty("network", when (network) { "tcp" -> "raw"; "h2" -> "http"; else -> network })
            if (tls) {
                addProperty("security", "tls")
                add("tlsSettings", JsonObject().apply {
                    addProperty("serverName", str("sni").ifBlank { str("host").substringBefore(',').ifBlank { host } })
                    add("alpn", com.google.gson.JsonArray().apply { add("h2"); add("http/1.1") })
                })
            }
            when (network) {
                "ws" -> add("wsSettings", JsonObject().apply {
                    addProperty("path", str("path", "/"))
                    val wsHost = str("host").ifBlank { host }
                    add("headers", JsonObject().apply { addProperty("Host", wsHost) })
                })
                "grpc" -> add("grpcSettings", JsonObject().apply { addProperty("serviceName", str("path")) })
                "http", "h2" -> add("httpSettings", JsonObject().apply {
                    addProperty("path", str("path", "/"))
                    add("host", com.google.gson.JsonArray().apply { add(str("host", host)) })
                })
                "tcp" -> if (str("type").equals("http", true)) add("tcpSettings", JsonObject().apply {
                    add("header", JsonObject().apply { addProperty("type", "http") })
                })
            }
        }
        val outbound = JsonObject().apply {
            addProperty("tag", str("ps").ifBlank { host })
            addProperty("protocol", "vmess")
            add("settings", JsonObject().apply {
                add("vnext", com.google.gson.JsonArray().apply {
                    add(JsonObject().apply {
                        addProperty("address", host); addProperty("port", port)
                        add("users", com.google.gson.JsonArray().apply {
                            add(JsonObject().apply {
                                addProperty("id", uuid)
                                addProperty("alterId", str("aid", "0").toIntOrNull() ?: 0)
                                addProperty("security", str("scy").ifBlank { "auto" })
                            })
                        })
                    })
                })
            })
            add("streamSettings", stream)
        }
        return Parsed(str("ps").ifBlank { host }, gson.toJson(JsonObject().apply { add("outbounds", com.google.gson.JsonArray().apply { add(outbound) }) }))
    }

    private fun pad(s: String) = s + "=".repeat((4 - s.length % 4) % 4)
}
