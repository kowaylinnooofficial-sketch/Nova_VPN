package com.nova.vpn.data

import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class VmessParserTest {
    @Test fun parsesLegacyVmessShareLink() {
        val json = """{"v":"2","ps":"TestNode","add":"example.com","port":"443","id":"00000000-0000-0000-0000-000000000000","aid":"0","net":"ws","path":"/ws","host":"example.com","tls":"tls"}"""
        val link = "vmess://" + Base64.getEncoder().withoutPadding().encodeToString(json.toByteArray())
        val parsed = VmessParser.parse(link)
        assertTrue(parsed.name == "TestNode")
        assertTrue(parsed.xrayJson.contains("example.com"))
        assertTrue(parsed.xrayJson.contains("vmess"))
    }
}
